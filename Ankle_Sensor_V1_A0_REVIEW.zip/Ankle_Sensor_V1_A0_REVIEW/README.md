# Ankle Sensor V1 — rewizja A0, projekt w toku

**Nie jest to dokumentacja zwolniona do produkcji ani komplet do zamówienia PCBA.** Stan z 27.10.2026: przegląd architektury, sprawdzone pinouty podstawowych układów i roboczy schemat elektryczny. Pamięć zwiększono z 64 do **128 MiB** bez zwiększenia korpusu układu: W25Q01JVZEIQ, JLCPCB C5137036. Większa pojemność wymaga obsługi dwóch matryc w sterowniku Flash.

Otwórz [projekt KiCad](hardware/Ankle_Sensor_V1.kicad_pro) oraz [schemat główny](hardware/Ankle_Sensor_V1.kicad_sch). Schemat ma pięć arkuszy: zasilanie, MCU/radio, IMU/pamięć, USB/SWD/przycisk oraz niezależna blokada temperatury ładowania. Symbole są osadzone w schematach i dostępne w lokalnej bibliotece `hardware/symbols/AnkleSensor.kicad_sym`.

Format docelowy jest zgodny ze strukturą plików KiCad 8+. **Nie potwierdzono odczytu plików w aplikacji KiCad.** W środowisku wykonania nie ma KiCad CLI, dostęp do Docker jest blokowany, a terminal nie ma dostępu DNS do pobrania instalatora. Użytkownik potwierdził brak instalacji KiCad i planuje ją wykonać. Dlatego nie uruchomiono ERC, DRC ani eksportera KiCad. Weryfikator Pythona sprawdza ograniczony zestaw połączeń i strukturę plików; jego PASS nie zastępuje tych kontroli.

## Pliki i status

| Wynik | Plik | Stan |
|---|---|---|
| Projekt i schemat | `hardware/*.kicad_pro`, `hardware/*.kicad_sch` | Edytowalny draft, odbiór przez KiCad nieprzetestowany |
| Biblioteka symboli | `hardware/symbols/AnkleSensor.kicad_sym` | Pinouty z dokumentacji; niezależna kontrola biblioteczna nadal wymagana |
| BOM | [reports/bom_draft.csv](reports/bom_draft.csv) | Częściowy dobór MPN/JLC; **nie do wysłania do montażu** |
| Połączenia i GPIO | [reports/pinmap.csv](reports/pinmap.csv) | Dane roboczego schematu |
| Kontrola statyczna | [reports/static_design_verification.md](reports/static_design_verification.md) | To nie ERC/DRC |
| Obliczenia ochrony NTC | `scripts/check_charge_temperature.py` | Model elektryczny, bez prób fizycznych |
| PCB, routing, Gerber, Drill, PnP, STEP | Brak | Nie utworzono pozornych plików produkcyjnych |

## Decyzje i ograniczenia

- MCU MDBT50Q-P1MV2, IMU LSM6DSV32XTR, Flash W25Q01JVZEIQ, ładowarka BQ25185DLHR, LDO TPS7A2030PDBVR 3.0 V/300 mA.
- Pełne wymagane ODR 120/240/480/960/1920 Hz są dostępne. SPI IMU i dwa przerwania; osobna magistrala QSPI pamięci.
- BQ25185 ze zwykłym NTC nie ogranicza ładowania do 0–45°C. Dodano niezależne okno TLV7042, nadzór napięcia TLV803E i dwa AO3400A. Prawdziwy pakiet, NTC i zachowanie przy starcie wymagają kwalifikacji. Blok temperatury pobiera na baterii około138µA według obliczeń.
- Limit wejścia USB 100 mA jest zachowawczy. Ładowanie 500 mAh przed upływem timera 360 min pozostaje problemem; nie należy deklarować pełnego ładowania takiego pakietu. Prototyp preferuje 300 mAh albo dopracowanie detekcji zasilacza/przełączania ILIM.
- PCB 50 × 28 mm / 4 warstwy to nadal cel mechaniczny, a nie potwierdzone rozmieszczenie. Nie odtworzono zgadywanego footprintu anteny ani modułu.
- Pasywa mają przypisane MPN i numeryC; część potwierdzono tylko w LCSC, a krytyczne MLCC wymagają kontroli pojemności pod napięciem. Brakuje ostatecznego doboru przycisku, LED, złącza baterii i mapowania padów wybranego USB-C. Dokładna geometria modułu Raytac i jego DCCH w trybie3V wymagają kontroli schematu referencyjnego.

## Dalsza praca

Najpierw zamknąć [listę kontroli](docs/release_checklist.md), wybrać konkretny akumulator i zweryfikować schemat w KiCad. Następnie biblioteki footprintów, rozmieszczenie, routing i sprawdzenie zgodności schemat↔PCB. Dopiero po rzeczywistych ERC/DRC i kontroli produkcyjnej powstaje paczka PCBA. Pierwsza produkcja powinna służyć uruchomieniu prototypu; funkcje firmware i jakość pomiaru wymagają testów na sprzęcie.

Dokumenty: [architektura](docs/architecture.md), [IMU/RF](docs/imu_rf_review.md), [zasilanie](docs/power_review.md), [pamięć i zaopatrzenie](docs/flash_sourcing.md), [zwiększenie pamięci](docs/memory_upgrade.md), [pasywa](docs/passives_sourcing.md), [niezależny przegląd](docs/independent_review.md), [wymagania firmware](docs/firmware_contract.md). Dostępny jest [podgląd schematu SVG](reports/schematic_review/index.html), wykonany własnym rendererem; nie jest to eksport z KiCad.

Odtworzenie draftu: `python3 -B scripts/build_design.py`. Nadpisuje wygenerowane schematy i manifest; po rozpoczęciu ręcznej edycji nie uruchamiać bez uzgodnienia zmian. Kontrola: `python3 -B scripts/verify_design.py --design hardware/design.json --schematic hardware/Ankle_Sensor_V1.kicad_sch --out-dir reports`.
