# Architektura i założenia A0

Stan: 2026-10-27, projekt w toku. Źródła parametrów i nierozwiązane kwestie są w trzech raportach komponentów. Nie wykonano prototypu ani routingu.

```mermaid
flowchart LR
  USB[USB-C:5V + USB2] --> CHG[BQ25185 + power path]
  PACK[Chroniony LiPo1S z NTC] <--> CHG
  NTC[NTC na ogniwie] --> WIN[Sprzętowe okno TLV7042]
  WIN -->|CE przez NMOS| CHG
  CHG -->|SYS| LDO[TPS7A2030:3.0V]
  LDO --> MCU[Raytac MDBT50Q-P1MV2]
  LDO --> IMU[LSM6DSV32X]
  LDO --> NOR[W25Q01JV:128MiB]
  IMU <-->|SPI + INT1/INT2| MCU
  MCU <-->|QSPI, adres32bit| NOR
  USB <-->|D+/D- przez ESD| MCU
  MCU <-->|BLE| HOST[Telefon / komputer]
  SWD[SWD pogo + reset] --> MCU
```

Moduły obu nóg są identyczne i pracują niezależnie. UID oraz jawna konfiguracja lewej/prawej nogi są metadanymi. PCB nie wymusza ODR, zakresów ani filtrów: dobiera je firmware. Nie ma magnetometru ani GPS. BLE służy sterowaniu, kotwicom synchronizacji i pobieraniu; podczas rejestracji nie jest niezbędne stałe połączenie.

## Zasilanie

Jest jedna regulowana szyna 3.0 V. VDD i VDDH modułu są razem, w normal voltage mode; VBUS trafia oddzielnie na dedykowany pin USB. SYS ładowarki może mieć około4.5 V i nie jest zasilaniem GPIO/Flash. LDO ma300 mA znamionowo; ostateczny budżet prądu i cieplny trzeba policzyć dla wybranej pamięci128 MiB i faktycznych trybów BLE. Dla orientacyjnego obciążenia100 mA strata LDO przy SYS4.5 V wynosi0.15 W — to obliczenie, nie zmierzony pik prądu.

EN LDO jest stale włączone. „Wyłączenie” przyciskiem to nRF System OFF, nie mechaniczne odłączenie baterii. Flash przechodzi w deep power-down, IMU w power-down; wartości standby trzeba zmierzyć. Dzielnik VBAT1M/1M pobiera około2.1 µA przy4.2 V. Blok NTC dodaje około138 µA w battery-only, ponieważ BQ nie polaryzuje wtedy TS, a komparator HOT ściąga pull-up100k. To świadomy koszt obecnej topologii, do pomiaru i ewentualnej optymalizacji; nie jest to projekt o standby liczonym w pojedynczych mikroamperach. Niskie zużycie energii całego urządzenia nie zostało jeszcze potwierdzone.

Zapis należy zakończyć z zapasem przed dropout i spadkiem3V poniżej minimum Flash. Docelowy próg VBAT należy ustalić po pomiarach pod obciążeniem, wstępnie około3.3 V; samo odcięcie PCM następuje zbyt późno do uporządkowanego zakończenia zapisu. Nie zakładać, że kondensatory pozwolą opróżnić cały RAM po nagłym odłączeniu.

## Pojemność

Planowanie konserwatywne:16 B na parę pomiarów accel+gyro wraz z uśrednionym narzutem;95% pamięci dostępne na sesje. To budżet projektowy, nie finalny format.

| Pamięć na moduł | 480Hz | 960Hz | 1920Hz |
|---|---:|---:|---:|
|64MiB, wariant pierwotny|138min|69min|35min|
|128MiB, aktualny draft|277min|138min|69min|
|256MiB, kierunek dalszego doboru|553min|277min|138min|

Dla porównania samo14 B tagowanego FIFO przy128 MiB i1920 Hz daje83.2 min przed innymi rekordami i rezerwą. Nie sumować pojemności obu nóg jako czasu jednego modułu. Zwiększenie NOR do128 MiB nie zmienia wymiaru korpusu8×6mm;256 MiB wymaga osobnego doboru dostępnej części i footprintu.

## Założenia PCB do późniejszego rozmieszczenia

Cel50×28mm, cztery warstwy: TOP sygnały/elementy, L2 ciągła GND, L3 zasilanie i wolne sygnały, BOTTOM sygnały/GND. Grubość, stackup i impedancja USB muszą pochodzić z wybranego stackupu JLCPCB. Nie przyjęto arbitralnej szerokości pary jako90Ω. Początkowo nie zakłada się microvia ani blind via.

Antena przy końcu płytki, z keepoutem na wszystkich warstwach zgodnym z Raytac; poza strefą także bateria i elementy obudowy. USB i przycisk na przeciwnym końcu względem IMU; sensor co najmniej10mm od punktu działania sił. Nie tworzyć elastycznej wyspy sensorowej bez analizy rezonansów. Nie stawiać ładowarki ani elementów cieplnych bezpośrednio przy IMU. Orientację osi trzeba zaznaczyć na warstwie opisowej i zapisać w metadanych.

Pamięć blisko szybkich pinów P0; zegar QSPI z rezystorem źródłowym22Ω do strojenia. SPI i QSPI bez długich odgałęzień testowych. Odsprzęganie przy pinach. Pod USB i zegarami ciągła droga powrotna; brak przejść nad szczelinami płaszczyzny. Ładowarka z polem termicznym i przelotkami według TI i technologii PCBA. Footprinty LGA/WSON i pasta wymagają kontroli producenta; nie domyślnego kopiowania z podobnej części.
