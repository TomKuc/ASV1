# Warunki ukończenia i zwolnienia A1

Aktualnie **A0-DRAFT / NOT FOR FABRICATION**. Żaden punkt nie jest domyślnie spełniony przez istnienie pliku ani przez PASS skryptu statycznego.

## Schemat i części

- [x] Przegląd oficjalnych dokumentów podstawowych IC, pinmapa61-pin Raytac VerL, pinouty IMU/Flash/ładowarki/LDO.
- [x] Roboczy schemat zasilania, USB, SWD, SPI+2INT, QSPI, LFXO i elementów użytkownika.
- [x] Wprowadzenie128 MiB W25Q01JVZEIQ/C5137036, korpus8×6mm.
- [x] Projekt dodatkowego oknaNTC, kontrola obliczeń tolerancji.
- [ ] Uruchomienie KiCad i potwierdzenie odczytu wszystkich schematów/symboli.
- [ ] Wizualne porównanie Raytac §8.3/USB z połączeniami DCCH i pojemnościami.
- [ ] Potwierdzenie LFXO: exact MPN, ESR, CL, tolerancja i kondensatory z pasożytamiPCB.
- [ ] Pakiet4.2V1S: MPN, pojemność, PCM, dopuszczalne ładowanie, wymiary, przewody/polaryzacja i dokładnyNTC na ogniwie.
- [ ] Dobór pasywów z DC-biasMLCC, tolerancją progówNTC0.1%, rezystorami programującymi i pełnymi MPN/JLC.
- [ ] Zamknięcie ładowania500mAh/timeout: kwalifikacja mniejszego pakietu albo detekcja źródła i legalne przełączanieILIM.
- [ ] USB2: suspend, inrush, ochronaCC/VBUS, mechanika i mapowanie zdublowanych padów oraz ekranuUSB-C.
- [ ] Zaopatrzenie Raytac, TLV7042, pamięci i wszystkich części w faktycznym BOM Tool JLCPCB Standard; brak niezatwierdzonych zamienników.
- [ ] Rzeczywisty ERC KiCad; wszystkie ostrzeżenia rozpatrzone i opisane.

## PCB

- [ ] Zweryfikowane footprinty: orientacjaTOP, pin1, pady wewnętrzne Raytac56–61, keepout anteny, EP/pastaWSON, LGAIMU i padyUSB.
- [ ] Dobór stackupu4L JLCPCB, grubości i impedancji90ΩUSB; próba rozmieszczenia50×28mm.
- [ ] Mechanika: dostępUSB, przycisk, polaSWD, bateria i przewody; brak dociskuIMU; antena poza baterią/metalem.
- [ ] Rozmieszczenie, odsprzęganie, zasilanie i termika; symetria połączeńIMU i brak miedzi/viasTOP pod korpusem wgST.
- [ ] Cały routing, ciągłaGND, poprawne powroty, QSPI/SPI, rezystor źródłowy i USB bez odgałęzień.
- [ ] Pola testowe, fiduciale montażowe i sposób panelizacji; ewentualny zapas technologiczny JLCPCB.
- [ ] Aktualizacja schemat↔PCB, poprawna zgodność netów, brak unrouted, rzeczywisty DRC i kontrola courtyards.
- [ ] Weryfikacja3D producentowych modeli oraz obudowy, wysokości i obszaru anteny.

## Paczka produkcyjna

- [ ] Gerber wszystkich warstw/obrysu/maski/pasty/opisów oraz ExcellonPTH/NPTH z rzeczywistegoPCB; kontrola w niezależnej przeglądarce.
- [ ] BOM z kompletem exact MPN i numerówC; PnP z warstwą, jednostkami, origin i rotacją sprawdzoną względem bibliotekJLC.
- [ ] STEP rzeczywistej płytki z kompletem modeli, jawna lista brakujących modeli.
- [ ] Raporty ERC/DRC z wersjąKiCad i hashem wejściowych plików; lista świadomych wyjątków.
- [ ] DFM/BOM/rotacje w podglądzie JLCPCB i jawny przegląd przed zamówieniem prototypów.

## Weryfikacja fizyczna

Dołączone wymagania w `firmware_contract.md` i `power_review.md`. Bez prototypu nie można potwierdzić jakości naukowej pomiaru, odporności na naprężenia, zgodnościUSB/RF, czasu pracy, przepustowości transferu, synchronizacji ani bezpieczeństwa cieplnego kompletnego urządzenia.
