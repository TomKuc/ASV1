# Statyczna kontrola schematu i manifestu

Status: **STATIC_CHECKS_PASS_KICAD_ERC_NOT_RUN**

**To nie jest ERC ani DRC KiCad. Nie stanowi zwolnienia do produkcji.**

Sprawdzono jedynie zgodność parsowanego schematu z manifestem oraz ograniczony model połączeń.

KiCad ERC: NOT RUN. KiCad DRC: NOT RUN.

- schematic_components: 71
- connected_pins_checked: 222
- nc_pins_checked: 31
- wires: 222
- labels: 222
- manifest_components: 71
- sheets: 6
- nets: 43
- uuids: 833
- errors: 0

## Wykryte problemy

Brak rozbieżności w objętym zakresem modelu statycznym. Wymagane otwarcie i ERC w KiCad.

BOM `bom_from_design.csv` pochodzi wyłącznie z manifestu. Nie potwierdza dostępności części ani montażu PCBA.
